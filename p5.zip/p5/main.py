# n=int (input())
# factorial=1
# for i in range(2, n+1):
#     factorial*=i
# print(factorial)
# n= (input("Введите число"))
# even = 0
# odd = 0
# for i in n :
#     if int(i) %2 == 0:
#         even += 1
#     else:
#         odd += 1
# print (even, odd)
