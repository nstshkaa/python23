# n="abcdef"
# a= int(n.__len__()/2)
# b=n.__len__()
# g=n[a:b]
#
# print(list(reversed(g)))